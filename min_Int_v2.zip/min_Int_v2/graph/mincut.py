import networkx as nx
import numpy as np

INFINITY = np.float32('inf')

# G: networkx graph
# sources: list of proxies
# target: a target variable
def minimum_cut(G, sources, target):
    G = G.copy()
    G.add_node('dummy') # add dummy source node
    for s in sources:
        G.add_edge('dummy', s, capacity=INFINITY)
    cut_value, partition = nx.minimum_cut(G, 'dummy', target)
    reachable, non_reachable = partition
    # find mininum cut
    cutset = []
    # retrieve every outgoing edges from the reachable set
    for node in reachable:
        for c in G.successors(node):
            if c not in reachable:
                cutset.append((node,c))
    return cut_value, cutset

